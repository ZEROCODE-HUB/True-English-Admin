import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Users,
  BookOpen,
  Brain,
  GitBranch,
  MessageSquare,
  BarChart3,
  CreditCard,
  Building2,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider } from "@/components/ui/sidebar";

import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";

const menuItems = [
  { id: "dashboard", title: "Panel de Control", icon: LayoutDashboard },
  { id: "users", title: "Gestión de Usuarios", icon: Users },
  { id: "courses", title: "Gestión de Cursos", icon: BookOpen },
  { id: "quizzes", title: "Gestión de Quizzes", icon: Brain },
  { id: "programs", title: "Programas y Niveles", icon: GitBranch },
  { id: "conversations", title: "Conversaciones con IA", icon: MessageSquare },
  { id: "plans", title: "Planes", icon: CreditCard },
  { id: "subscriptions", title: "Suscripciones", icon: BarChart3 },
  { id: "companies", title: "Empresas", icon: Building2 },
];
export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigate = (id: string) => {
    const path = `/${id}`;
    navigate(path);
  };

  const { signOut } = useAuth();

  const { user, isAdmin, loading } = useAuth();
  const [profile, setProfile] = useState<{ name?: string | null; last_name?: string | null; email?: string | null } | null>(null);

  useEffect(() => {
    let mounted = true;
    const loadProfile = async () => {
      if (!user?.id) return setProfile(null);
      try {
        const { data, error } = await supabase.from('profiles').select('name,last_name,email').eq('id', user.id).maybeSingle();
        if (error) {
          console.error('failed to load profile', error);
          return;
        }
        if (!mounted) return;
        setProfile(data ?? null);
      } catch (e) {
        console.error('failed to load profile', e);
      }
    };
    loadProfile();
    return () => { mounted = false };
  }, [user]);

  const handleLogout = async () => {
    await signOut();
    navigate("/login");
  };

  // Gating: si hay sesión pero la cuenta no es admin, no mostrar el panel.
  if (!loading && user && !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-background">
        <div className="max-w-md text-center space-y-4">
          <h1 className="text-2xl font-bold">Acceso restringido</h1>
          <p className="text-muted-foreground">Esta cuenta no tiene permisos de administrador.</p>
          <Button onClick={handleLogout}>Cerrar sesión</Button>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar className="w-64 border-r bg-primary">
          <SidebarContent>
            <div className="p-6 border-b border-sidebar-border">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                  <span className="text-accent-foreground font-bold text-sm">TE</span>
                </div>
                <div>
                  <h1 className="text-sidebar-foreground font-bold">TrueEnglish</h1>
                  <p className="text-sidebar-foreground/80 text-sm">Academy Admin</p>
                </div>
              </div>
            </div>

            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menuItems.map((item) => (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        onClick={() => handleNavigate(item.id)}
                        className={`w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent ${location.pathname === `/${item.id}` || location.pathname.startsWith(`/${item.id}/`) || (item.id === "dashboard" && location.pathname === "/")
                          ? "bg-sidebar-accent"
                          : ""
                          }`}
                      >
                        <item.icon className="w-5 h-5 mr-3" />
                        {item.title}
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <div className="mt-auto p-4 border-t border-sidebar-border">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center overflow-hidden">
                  {(user?.user_metadata?.avatar_url || user?.user_metadata?.picture) ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={(user.user_metadata.avatar_url || user.user_metadata.picture) as string} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-accent-foreground font-bold">{(profile?.name ? profile.name[0] : (user?.email ? user.email[0] : 'U')).toUpperCase()}</span>
                  )}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-sidebar-foreground">{profile?.name ? `${profile.name}${profile.last_name ? ' ' + profile.last_name : ''}` : user?.email}</div>
                  <div className="text-xs text-sidebar-foreground/80">{profile?.email ?? user?.email}</div>
                </div>
              </div>

              <Button
                onClick={handleLogout}
                className="w-full justify-start bg-[hsl(220,70%,25%)] text-white hover:bg-[hsl(220,70%,25%)] border-0"
              >
                <LogOut className="w-5 h-5 mr-3" />
                Cerrar Sesión
              </Button>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 min-w-0 bg-background overflow-x-hidden">
          <div className="p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}